// Fill out your copyright notice in the Description page of Project Settings.


#include "Player/Character/Component/Repel/RepelComponent.h"

#include "Player/Character/WaterGun/WaterGunBase.h"

void URepelComponent::RegisterSpawnedWaterGun(FGameplayTag WaterGunTag, AWaterGunBase* WaterGun,
                                              bool bRegisterAsEquippedWeapon)
{
	checkf(!RunnerCarriedWaterGunMap.Contains(WaterGunTag), TEXT("%s has already been as Carried WaterGun"), *WaterGunTag.ToString());
	check(WaterGun)

	RunnerCarriedWaterGunMap.Emplace(WaterGunTag, WaterGun);

	if (bRegisterAsEquippedWeapon)
	{
		CurrentEquippedWaterGunTag = WaterGunTag;
		
	}
}

AWaterGunBase* URepelComponent::GetCharacterCarriedWaterGunByTag(FGameplayTag WaterGunTag) const
{
	if (!RunnerCarriedWaterGunMap.Contains(WaterGunTag))
	{
		if (AWaterGunBase* const* FoundWaterGun = RunnerCarriedWaterGunMap.Find(WaterGunTag))
		{
			return *FoundWaterGun;
		}
	}
	return nullptr;
}

AWaterGunBase* URepelComponent::GetCharacterCurrentEquippedWaterGun() const
{
	if (!CurrentEquippedWaterGunTag.IsValid())
	{
		return nullptr;
	}

	return GetCharacterCarriedWaterGunByTag(CurrentEquippedWaterGunTag);
}
