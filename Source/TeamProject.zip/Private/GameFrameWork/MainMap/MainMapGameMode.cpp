#include "GameFrameWork/MainMap/MainMapGameMode.h"
#include "GameFramework/Character.h"
#include "GameFrameWork/MainMap/MainMapPlayerState.h"
#include "GameFrameWork/MainMap/MainMapGameState.h"
#include "GameFrameWork/MainMap/MainMapPlayerController.h"
#include "Kismet/GameplayStatics.h"

void AMainMapGameMode::GameStart()
{
	if (!MainMapGameState->IsValidLowLevel())
	{
		return;
	}
	
	MainMapGameState->SetRemainSecond(GameProgressTime);
	
	//Select Tagger
	//----------------------------------------------------
	int32 CurTaggerCount = 0;
	TArray<bool> TaggerArr;
	TaggerArr.Init(false,IDArr.Num());
	int32 CurPlayerNum = IDArr.Num();
	while (CurTaggerCount < TaggerNum)
	{
		int32 CurRandomIdx = FMath::RandRange(0,CurPlayerNum - 1);
		if (TaggerArr[CurRandomIdx])
			continue;
		else
		{
			TaggerArr[CurRandomIdx] = true;
			++CurTaggerCount;
		}		
	}
	//----------------------------------------------------

	//Spawn Player
	//----------------------------------------------------
	for (int Idx = 0; Idx < CurPlayerNum; ++Idx)
	{
		int32 CurPlayerServerNumberID = IDArr[Idx];
		bool IsTagger = TaggerArr[Idx];

		AMainMapPlayerState * CurPlayerState = MainMapPlayerStateMap[CurPlayerServerNumberID];
		APlayerController * CurPlayerController = GameControllersMap[CurPlayerServerNumberID];
		ACharacter * CurCharacter = CurPlayerController->GetCharacter();
		
		if (!IsValid(CurPlayerState) || !IsValid(CurPlayerController) ||
			!IsValid(CurCharacter)) continue; //Init?
	
		if (IsTagger)
		{
			CurPlayerState->SetTagger();
			CurCharacter->SetActorLocation(TaggerInitLocationArr[Idx]);
		}
		else
		{
			CurCharacter->SetActorLocation(PlayerStartPositionArr[Idx]);
		}
	}

	//----------------------------------------------------

}

void AMainMapGameMode::InitPlayerStartPosition()
{
	int8 Size = GameControllersMap.Num();
	int Idx = 0;
	for (auto ControllerInfo : GameControllersMap)
	{
		APlayerController * PlayerController = ControllerInfo.Value;
		if (!IsValid(PlayerController)) return;
		
		if (ACharacter * Player = ControllerInfo.Value->GetCharacter())
		{
			Player->SetActorLocation(PlayerStartPositionArr[Idx]);
			++Idx;
		}
	}		
}

void AMainMapGameMode::BeginPlay()
{
	Super::BeginPlay();

	MainMapGameState = Cast<AMainMapGameState>(UGameplayStatics::GetGameState(this));
}

void AMainMapGameMode::PostLogin(APlayerController* NewPlayer)
{
	Super::PostLogin(NewPlayer);
	
	if (GameControllersMap.Num() < MaxNumOfPlayers)
	{
		AMainMapPlayerState* NewPlayerState = Cast<AMainMapPlayerState>(NewPlayer->PlayerState);
		if (IsValid(NewPlayerState) && IsValid(NewPlayer))
		{
			MainMapPlayerStateMap.Add(IDCounter, NewPlayerState);			
			GameControllersMap.Add(IDCounter, NewPlayer);
			NewPlayerState->ServerNumberID = MainMapPlayerStateMap.Num();
			IDArr.Add(IDCounter);

			NewPlayerState->PlayerNickName = FString(TEXT("학생")) + FString::FromInt(IDCounter);
			
			++IDCounter;
		}
	}
}

