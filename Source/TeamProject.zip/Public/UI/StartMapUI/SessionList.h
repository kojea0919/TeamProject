#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "SessionList.generated.h"

UCLASS()
class TEAMPROJECT_API USessionList : public UUserWidget
{
	GENERATED_BODY()
	
};
