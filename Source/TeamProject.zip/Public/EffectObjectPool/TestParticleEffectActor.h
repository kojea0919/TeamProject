// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "EffectObjectPool/ParticleEffectActor.h"
#include "TestParticleEffectActor.generated.h"

/**
 * 
 */
UCLASS()
class TEAMPROJECT_API ATestParticleEffectActor : public AParticleEffectActor
{
	GENERATED_BODY()
	
};
