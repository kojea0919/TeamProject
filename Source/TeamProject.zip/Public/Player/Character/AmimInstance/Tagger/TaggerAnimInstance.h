// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Player/Character/AmimInstance/CharacterAnimInstance.h"
#include "TaggerAnimInstance.generated.h"

/**
 * 
 */
UCLASS()
class TEAMPROJECT_API UTaggerAnimInstance : public UCharacterAnimInstance
{
	GENERATED_BODY()
	
};
