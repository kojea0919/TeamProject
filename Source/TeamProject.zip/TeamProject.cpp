// Fill out your copyright notice in the Description page of Project Settings.

#include "TeamProject.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, TeamProject, "TeamProject" );
